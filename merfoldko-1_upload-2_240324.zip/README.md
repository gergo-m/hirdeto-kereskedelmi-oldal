# hirdeto-kereskedelmi-oldal
 Egy weboldal, ahol helyi vállalkozások tudják magukat hirdetni. A felhasználók tudják értékelni a szolgáltatásokat, rendelni tudnak a cégektől egy felületen keresztül. A vállalkozók fel tudják tenni saját vállalkozásuk szolgáltatásait, mindenféle információval ellátni ezt. Az adminok az új vállalkozásokat tudják jóváhagyni az oldalra, a meglévők adatait módosítani.

Az SZTE TTIK webtervezés kurzusára készített projektmunka.